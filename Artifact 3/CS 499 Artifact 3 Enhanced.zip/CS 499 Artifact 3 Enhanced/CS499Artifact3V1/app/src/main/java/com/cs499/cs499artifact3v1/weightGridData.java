/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file contains the data for the 'main' page.

This file contains the table 'weighGridData' that is utilized for the daily weights for the user.
    It contains the information for the table and the getter/setter methods for this data.
 */

package com.cs499.cs499artifact3v1;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

//Creates table, getters, setters, and constructor for weight grid data
@Entity
public class weightGridData {

    //Table creation and information for the columns
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long wId;

    @ColumnInfo(name = "uniqueID")
    private long wUniqueID;

    //@NonNull
    @ColumnInfo(name = "day")
    private String wDay;

    @ColumnInfo(name = "weight")
    private String wWeight;

    //General constructor for data manipulation
    public weightGridData () {
    }

    //Getter/setter methods
    public void setWId(long wId) {
        this.wId = wId;
    }

    public void setWDay(String wDay) {
        this.wDay = wDay;
    }

    public void setWWeight(String wWeight) {
        this.wWeight = wWeight;
    }

    public void setWUniqueID(long wUniqueID) { this.wUniqueID = wUniqueID; }

    public long getWId() {
        return wId;
    }

    public long getWUniqueID() { return wUniqueID; }

    public String getWDay() {
        return wDay;
    }

    public String getWWeight() {
        return wWeight;
    }

}
