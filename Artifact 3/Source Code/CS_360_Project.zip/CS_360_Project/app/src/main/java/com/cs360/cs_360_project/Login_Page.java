package com.cs360.cs_360_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//Allows user to login into app
public class Login_Page extends AppCompatActivity {

    //Interacts with fields
    EditText username;
    EditText password;
    Button loginButton;

    Button signUpButton;

    static appDatabase appDatabase;

    //Constuctor
    public Login_Page() {
    }

    //Opens when app is called
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        //Sets up database connection
        appDatabase = Room.databaseBuilder(getApplicationContext(),
                        appDatabase.class, "app_database.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        //Finds references
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.signUpButton);

        //Performs login functions. If valid, allows access. If not, notifies user.
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String usernameInput = username.getText().toString().toLowerCase();
                String passwordInput = password.getText().toString().toLowerCase();



                String usernameVerification = verifyUsername(usernameInput, passwordInput);
                String passwordVerification = verifyPassword(usernameInput, passwordInput);

                if (username.getText().toString().equals(usernameVerification) && password.getText().toString().equals(passwordVerification)) {
                    Toast.makeText(Login_Page.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                    intent.putExtra("username", usernameVerification);
                    intent.putExtra("password", passwordVerification);
                    startActivity(intent);
                }


                else {
                    Toast.makeText(Login_Page.this, "Login Failed!", Toast.LENGTH_SHORT).show();
                }
            }

        });

        //Allows user to sign up on sign up page
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), signUpScreen.class);
                startActivity(intent);
            }
        });
    }



    //function to verify username against database
    private String verifyUsername(String username, String password) {

        String value = appDatabase.loginPageDataDAO().getUsername(username, password);

        return value;
    }

    //function to verify password against database
    private String verifyPassword(String username, String password) {

        String value = appDatabase.loginPageDataDAO().getPassword(username, password);

        return value;
    }

}