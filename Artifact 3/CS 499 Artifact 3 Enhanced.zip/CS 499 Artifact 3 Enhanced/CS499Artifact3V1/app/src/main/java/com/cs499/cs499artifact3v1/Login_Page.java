/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file allows for the usage of the login system of the app.

This page contains a check system against the database for proper username/password configuration.
    If valid, provides access.
    If not, prompts user invalid.

This page allows the user to utilize the 'sign up' feature to create an account with unique data storage,
    username, and password functions.
 */

package com.cs499.cs499artifact3v1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

//Allows user to login into app
public class Login_Page extends AppCompatActivity {

    //Interacts with fields of the xml page 'login_screen'
    EditText username;
    EditText password;
    Button loginButton;

    Button signUpButton;

    static appDatabase appDatabase;

    /* Unique ID identifier that will allow for custom user experience */
    static long uniqueID = 0;

    //Opens login page when app is called from first user interaction
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        //Sets up database connection
        appDatabase = Room.databaseBuilder(getApplicationContext(),
                        appDatabase.class, "app_database.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        //Finds references to fields specified earlier
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.signUpButton);

        //Performs login functions. If valid, allows access. If not, notifies user.
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //takes in user information
                String usernameInput = username.getText().toString().toLowerCase();
                String passwordInput = password.getText().toString().toLowerCase();

                //check methods for username/password
                String usernameVerification = verifyUsername(usernameInput, passwordInput);
                String passwordVerification = verifyPassword(usernameInput, passwordInput);

                //check function
                if (username.getText().toString().equals(usernameVerification) && password.getText().toString().equals(passwordVerification)) {

                    /* This allows for user experience to be unique */
                    uniqueID = appDatabase.loginPageDataDAO().getID(usernameInput, passwordInput);


                    //outputs successful login message and moves to main page
                    Toast.makeText(Login_Page.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                    //intent.putExtra("username", usernameVerification);
                    //intent.putExtra("password", passwordVerification);
                    startActivity(intent);
                }


                else {
                    Toast.makeText(Login_Page.this, "Login Failed!", Toast.LENGTH_SHORT).show();
                }
            }

        });

        //Allows user to sign up on sign up page
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), signUpScreen.class);
                startActivity(intent);
            }
        });
    }



    //function to verify username against database
    private String verifyUsername(String username, String password) {

        String value = appDatabase.loginPageDataDAO().getUsername(username, password);

        return value;
    }

    //function to verify password against database
    private String verifyPassword(String username, String password) {

        String value = appDatabase.loginPageDataDAO().getPassword(username, password);

        return value;
    }

}