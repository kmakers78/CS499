package com.cs360.cs_360_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;


//Allows user to sign up with app for access
public class signUpScreen extends AppCompatActivity {

    //References
    EditText username;
    EditText password;
    EditText phoneNumber;
    Button confirmSignUp;
    Button returnButton;


    private appDatabase appDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_screen);

        //sets up database connection
        appDatabase = Room.databaseBuilder(getApplicationContext(),
                        appDatabase.class, "app_database.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        //Finds references
        username = findViewById(R.id.username_1);
        password = findViewById(R.id.password_1);
        phoneNumber = findViewById(R.id.phoneNumberEntry);
        confirmSignUp = findViewById(R.id.confirmSignUpButton);
        returnButton = findViewById(R.id.signUpReturn);


        //Checks for values in system or not.
        //If not, adds user
        //If it exists, will prompt user
        confirmSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String usernameInput = username.getText().toString().toLowerCase();
                String passwordInput = password.getText().toString().toLowerCase();
                String phoneNumberInput = phoneNumber.getText().toString();

                loginPageData loginPageData_data_input = new loginPageData();

                String usernameVerification = verifyUsername(usernameInput, passwordInput);
                String passwordVerification = verifyPassword(usernameInput, passwordInput);

                if (usernameInput.equals(usernameVerification) && passwordInput.equals(passwordVerification)) {
                    Toast.makeText(signUpScreen.this, "ERROR: Login info already exists!", Toast.LENGTH_SHORT).show();
                }


                else {

                    loginPageData_data_input.setLUsername(usernameInput);
                    loginPageData_data_input.setLPassword(passwordInput);
                    loginPageData_data_input.setPhoneNumber(phoneNumberInput);

                    appDatabase.loginPageDataDAO().addUsernamePassword(loginPageData_data_input);

                    Toast.makeText(signUpScreen.this, "SUCCESS: Login info added!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    startActivity(intent);
                }
            }

        });

        //Allows user to return to login page without signing up with new information
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                startActivity(intent);

            }
        });

    }


    private String verifyUsername(String username, String password) {

        String value = appDatabase.loginPageDataDAO().getUsername(username, password);
        
        return value;
    }

    private String verifyPassword(String username, String password) {

        String value = appDatabase.loginPageDataDAO().getPassword(username, password);

        return value;
    }


}