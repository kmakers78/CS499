package com.cs360.cs_360_project;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ColumnInfo;
import androidx.room.PrimaryKey;





//Creates table, getters, setters, and constructor for target weight data
@Entity
public class targetWeightData {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private Long twId;

    @ColumnInfo(name = "weight")
    private String tWeight;


    public targetWeightData (@NonNull String weight) {

        tWeight = weight;
    }

    public targetWeightData(){};

    public void setTwId(long twId) {
        this.twId = twId;
    }

    public void setTWeight(String tWeight) {
        this.tWeight = tWeight;
    }

    public Long getTwId() {
        return twId;
    }

    public String getTWeight() {
        return tWeight;
    }
}
