/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file allows for the usage of the target weight portion of the app.

This file contains the field fillers for the xml 'database_grid_target_weight_screen,
    return to main page,
    and database manipulations for the 'target weight' table.
        database manipulations include adding a new target weight or modifying an exiting one.

 */
package com.cs499.cs499artifact3v1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

//Class for entering/modifying a target weight

public class Target_Weight extends AppCompatActivity {

    //References for layout on xml page 'database_grid_target_weight_screen'
    EditText weight;
    Button addEntry;
    Button returnButton;

    //Allows for database usage
    private appDatabase appDatabase;

    //Creates page on access
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database_grid_target_weight_screen);

        //sets up connection to database
        appDatabase = Room.databaseBuilder(getApplicationContext(),
                        appDatabase.class, "app_database.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        //finds references to xml layout features above
        weight = findViewById(R.id.weight_1);
        returnButton = findViewById(R.id.returnButton2);
        addEntry = findViewById(R.id.addEntry2);

        //Allows user to add/modify target weight for app
        addEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Takes in user information
                String thisWeight = weight.getText().toString().toLowerCase();

                //Utilizes constructor to store in information
                targetWeightData targetWeightData = new targetWeightData();

                //Sets target weight
                targetWeightData.setTWeight(thisWeight);

                /* Below allows for checking if target weight is in database for user.
                If it is, allows for only modifying of target weight.
                If it is not, adds unique target weight for specific user.

                This reduces size of database and allows for unique experience of app.
                 */
                int checker = 0;

                checker = appDatabase.targetWeightDAO().countTargetWeightData();

                if (checker < Login_Page.uniqueID) {

                    appDatabase.targetWeightDAO().addTargetWeight(targetWeightData);
                }

                appDatabase.targetWeightDAO().updateTargetWeightByID(thisWeight, Login_Page.uniqueID);

                //Outputs successful entry
                Toast.makeText(Target_Weight.this, "Entry Successful!", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);
            }
        });

        //Allows user to return to main page without adding/editing target weight
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

    }
}