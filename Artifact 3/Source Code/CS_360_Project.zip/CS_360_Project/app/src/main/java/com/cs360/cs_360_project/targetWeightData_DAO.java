package com.cs360.cs_360_project;

import androidx.room.*;

//Allows DAO access to target weight data table
@Dao
public interface targetWeightData_DAO {
    @Query("SELECT weight FROM targetWeightData WHERE id = :id LIMIT 1")
    String getTargetWeight(long id);

    //@Query("SELECT * FROM targetWeightData ORDER BY text COLLATE NOCASE")
    //List<Subject> getSubjects();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addTargetWeight(targetWeightData targetWeightData);

    @Update
    void updateTargetWeight(targetWeightData targetWeight);

    @Query("UPDATE targetWeightData SET weight = :newWeight WHERE id = :id")
    void updateTargetWeightByID(String newWeight, long id);

    @Delete
    void deleteTargetWeight(targetWeightData targetWeight);
}