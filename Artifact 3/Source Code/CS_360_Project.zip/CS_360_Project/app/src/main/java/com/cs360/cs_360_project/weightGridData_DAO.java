package com.cs360.cs_360_project;

import androidx.room.*;

import java.util.List;

//Allows DAO access to weight grid data table
@Dao
public interface weightGridData_DAO {
    @Query("SELECT weight FROM weightGridData WHERE day = :day")
    String getWeightByDay(String day);

    @Query("SELECT * FROM weightGridData")
    List<weightGridData> getAllWeightGridData();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addWeight(weightGridData weightGridData);

    @Update
    void updateWeight(weightGridData weightGridData);

    @Query("UPDATE weightGridData SET weight = :newWeight WHERE day = :day")
    void updateWeightIfDayExists(String day, String newWeight);

    @Delete
    void deleteWeight(weightGridData weightGridData);

    @Query("DELETE FROM weightGridData WHERE day = :day")
    void deleteWeightByDay(String day);

    //FOR TESTING PURPOSES ONLY!!!
    @Query("DELETE FROM weightGridData")
    void clearTable();
}
