package com.cs360.cs_360_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import java.util.ArrayList;

//Class for entering/modifying a target weight

public class Target_Weight extends AppCompatActivity {

    //References
    EditText weight;
    Button addEntry;
    Button returnButton;

    private appDatabase appDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database_grid_target_weight_screen);

        //sets up connection to database
        appDatabase = Room.databaseBuilder(getApplicationContext(),
                        appDatabase.class, "app_database.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        //finds references
        weight = findViewById(R.id.weight_1);
        returnButton = findViewById(R.id.returnButton2);
        addEntry = findViewById(R.id.addEntry2);

        //Allows user to add/modify target weight for app
        addEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String thisWeight = weight.getText().toString().toLowerCase();

                long id = 1;

                targetWeightData targetWeightData = new targetWeightData();


                targetWeightData.setTWeight(thisWeight);

                appDatabase.targetWeightDAO().addTargetWeight(targetWeightData);
                appDatabase.targetWeightDAO().updateTargetWeightByID(thisWeight, id);



                Toast.makeText(Target_Weight.this, "Entry Successful!", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

        //Allows user to return to main page without adding/editing target weight
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

    }
}