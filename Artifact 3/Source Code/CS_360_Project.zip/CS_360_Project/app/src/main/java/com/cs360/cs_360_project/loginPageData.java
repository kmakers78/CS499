package com.cs360.cs_360_project;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;






//Creates table, getters, setters, and constructor for login page data
@Entity
public class loginPageData {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long lId;

    @ColumnInfo(name = "username")
    private String lUsername;

    @ColumnInfo(name = "password")
    private String lPassword;

    @ColumnInfo(name = "phoneNumber")
    private String phoneNumber;


    public loginPageData() {
    }


    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public long getLId() {
        return lId;
    }

    public void setLId(long lId) {
        this.lId = lId;
    }

    public String getLUsername() {
        return lUsername;
    }

    public void setLUsername(String lUsername) {
        this.lUsername = lUsername;
    }

    public String getLPassword() {
        return lPassword;
    }

    public void setLPassword(String lPassword) {
        this.lPassword = lPassword;
    }
}
