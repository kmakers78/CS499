/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file allows for the 'adding' and 'modifying' of the daily weights.
    It interacts with the database_grid_add_entry_screen to allow users to set which day with a weight.
    These weights are then updated on the main_page java file and the database_grid (main) screen

This file pulls the data for the databases of weights from 'weightGridData' and
    the SQL queries from 'weightGridData_DAO'.
 */

package com.cs499.cs499artifact3v1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

//Class creation to allow for add/modify weights
public class Add_Modify_Weight_Entry extends AppCompatActivity {

    //References to fields on xml page design of 'database_grid_add_entry_screen'
    EditText day;
    EditText weight;
    Button addEntry;

    Button returnButton;

    //allows for database operations
    private appDatabase appDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database_grid_add_entry_screen);

        //Sets up connection to database
        appDatabase = Room.databaseBuilder(getApplicationContext(),
                        appDatabase.class, "app_database.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        //Finds references
        day = findViewById(R.id.day);
        weight = findViewById(R.id.weight);
        returnButton = findViewById(R.id.returnButton1);
        addEntry = findViewById(R.id.addEntry1);

        //Allows user to add/modify weight in grid on main page
        addEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //takes in user input
                String thisDay = day.getText().toString().toLowerCase();
                String thisWeight = weight.getText().toString().toLowerCase();

                //stores user input into constructor to use for add/modify values
                weightGridData weightGridData = new weightGridData();

                weightGridData.setWUniqueID(Login_Page.uniqueID);
                weightGridData.setWDay(thisDay);
                weightGridData.setWWeight(thisWeight);

                //checks for if value at specific day/id is empty or not
                int checker = appDatabase.weightGridDataDAO().countDayWeightGridData(Login_Page.uniqueID, thisDay);

                //if empty, add values
                if (checker == 0) {

                    appDatabase.weightGridDataDAO().addWeight(weightGridData);
                }

                //if not empty, modify values
                appDatabase.weightGridDataDAO().updateWeightIfDayExists(Login_Page.uniqueID, thisDay, thisWeight);

                //outputs successful modification
                Toast.makeText(Add_Modify_Weight_Entry.this, "Entry Successful!", Toast.LENGTH_SHORT).show();

                //back to home screen
                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

        //Allows user to return to main page if they don't want to edit or add weights
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

    }
}