/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file operates the 'sign up' feature for the app.
    It contains code to set the various fields on the 'sign_up_screen' xml for layout,
        interacts with the login database to add users,
        checks if a user exists or not (to ensure no duplicates),
        and return to login page.
    Users are added with a username, password, and phone number.
 */

package com.cs499.cs499artifact3v1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;


//Allows user to sign up with app for access
public class signUpScreen extends AppCompatActivity {

    //References for 'sign_up_screen' xml page layout
    EditText username;
    EditText password;
    EditText phoneNumber;
    Button confirmSignUp;
    Button returnButton;

    //Allows for database interactions
    private appDatabase appDatabase;

    //Creates page on access
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_screen);

        //sets up database connection
        appDatabase = Room.databaseBuilder(getApplicationContext(),
                        appDatabase.class, "app_database.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        //Finds references for above xml layout items
        username = findViewById(R.id.username_1);
        password = findViewById(R.id.password_1);
        phoneNumber = findViewById(R.id.phoneNumberEntry);
        confirmSignUp = findViewById(R.id.confirmSignUpButton);
        returnButton = findViewById(R.id.signUpReturn);


        //Checks for values in system or not.
        //If not, adds user
        //If it exists, will prompt user
        confirmSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String usernameInput = username.getText().toString().toLowerCase();
                String passwordInput = password.getText().toString().toLowerCase();
                String phoneNumberInput = phoneNumber.getText().toString();

                //constructor to hold user information to add to database
                loginPageData loginPageData_data_input = new loginPageData();

                //verify input functions
                String usernameVerification = verifyUsername(usernameInput, passwordInput);
                String passwordVerification = verifyPassword(usernameInput, passwordInput);

                //verification loop
                //If exists, output error message
                if (usernameInput.equals(usernameVerification) && passwordInput.equals(passwordVerification)) {
                    Toast.makeText(signUpScreen.this, "ERROR: Login info already exists!", Toast.LENGTH_SHORT).show();
                }

                //Else adds user
                else {

                    loginPageData_data_input.setLUsername(usernameInput);
                    loginPageData_data_input.setLPassword(passwordInput);
                    loginPageData_data_input.setPhoneNumber(phoneNumberInput);

                    appDatabase.loginPageDataDAO().addUsernamePassword(loginPageData_data_input);

                    Toast.makeText(signUpScreen.this, "SUCCESS: Login info added!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    startActivity(intent);
                }
            }

        });

        //Allows user to return to login page without signing up with new information
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                startActivity(intent);

            }
        });

    }

    //Verify username/password functions for uniqueness
    private String verifyUsername(String username, String password) {

        String value = appDatabase.loginPageDataDAO().getUsername(username, password);
        
        return value;
    }

    private String verifyPassword(String username, String password) {

        String value = appDatabase.loginPageDataDAO().getPassword(username, password);

        return value;
    }


}