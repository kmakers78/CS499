package com.cs360.cs_360_project;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

//Allows DAO access to login page data table
@Dao
public interface loginPageData_DAO {

    @Query("SELECT * FROM loginPageData WHERE username = :username AND password = :password AND phoneNumber = :phoneNumber")
    loginPageData loginPageData(String username, String password, String phoneNumber);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addUsernamePassword(loginPageData loginPageData);

    @Query("SELECT username FROM loginPageData WHERE username = :username AND password = :password")
    String getUsername(String username, String password);

    @Query("SELECT password FROM loginPageData WHERE username = :username AND password = :password")
    String getPassword(String username, String password);

    @Query("SELECT phoneNumber FROM loginPageData WHERE username = :username AND password = :password")
    String getPhoneNumber(String username, String password);

    @Update
    void updateLogin(loginPageData loginPageData);

    @Delete
    void deleteLogin(loginPageData loginPageData);
}
