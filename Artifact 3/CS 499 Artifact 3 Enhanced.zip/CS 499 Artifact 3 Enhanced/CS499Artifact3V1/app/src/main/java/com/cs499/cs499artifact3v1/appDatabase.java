/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file contains all the database constructors.
    It creates the entities of the database via the respective classes.
    It creates tables based on the classes provided.
    The system uses SQL lite with DAO to access the CRUD operations and other
    various queries within each section of the database.

    It is organized in xxx-PageData, xxx-PageDAO, and xxx-Page.
        xxx-PageData contains all the values for the table and setters/getters
        xxx-PageDAO allows for SQL queries
        xxx-Page is the page for utilization and manipulation of the database for its
        respective data required.

 */

package com.cs499.cs499artifact3v1;

import androidx.room.Database;
import androidx.room.RoomDatabase;


//Database for app, contains all classes to make into tables
@Database(entities = {weightGridData.class, targetWeightData.class, loginPageData.class}, version = 4)
public abstract class appDatabase extends RoomDatabase {

    //DAO accessors
    public abstract targetWeightData_DAO targetWeightDAO();
    public abstract weightGridData_DAO weightGridDataDAO();
    public abstract loginPageData_DAO loginPageDataDAO();

}

