/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file contains the 'target weight data' table information.
    This includes the column information and layout for the table,
    and the getter/setter methods for this information.
 */

package com.cs499.cs499artifact3v1;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;





//Creates table, getters, setters, and constructor for target weight data
@Entity
public class targetWeightData {

    //Table information
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private Long twId;

    @ColumnInfo(name = "uniqueId")
    private long twUniqueId;

    @ColumnInfo(name = "weight")
    private String tWeight;

    //Getter/setter methods
    public targetWeightData(){};

    public void setTwId(long twId) {
        this.twId = twId;
    }

    public void setTwUniqueId(long twUniqueId) {this.twUniqueId = twUniqueId;}
    public Long getTwUniqueId() {return twUniqueId;}

    public void setTWeight(String tWeight) {
        this.tWeight = tWeight;
    }

    public Long getTwId() {
        return twId;
    }

    public String getTWeight() {
        return tWeight;
    }

}
