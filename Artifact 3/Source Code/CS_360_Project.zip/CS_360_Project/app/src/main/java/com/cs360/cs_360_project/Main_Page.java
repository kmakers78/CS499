package com.cs360.cs_360_project;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

//Main page of application

public class Main_Page extends AppCompatActivity {

    // All interactions, variables, and methods used in class
    Button changeTargetWeight;
    Button addEntry;
    Button modifyEntry;

    Button textPermissions;

    Button delete_entry_1;
    Button delete_entry_2;
    Button delete_entry_3;
    Button delete_entry_4;
    Button delete_entry_5;
    Button delete_entry_6;
    Button delete_entry_7;


    TextView targetWeight;
    TextView day1;
    TextView day2;
    TextView day3;
    TextView day4;
    TextView day5;
    TextView day6;
    TextView day7;


    textPermissions textPermissionsForMainPage = new textPermissions();

    static appDatabase appDatabase;



//Creates main page
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database_grid);

        //Gets username and password that were used to login for SMS messaging purposes
        String username = getIntent().getStringExtra("username");
        String password = getIntent().getStringExtra("password");

        //Builds database
        appDatabase = Room.databaseBuilder(getApplicationContext(),
                        appDatabase.class, "app_database.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();


        //Find references
        changeTargetWeight = findViewById(R.id.ChangeTargetWeight);
        addEntry = findViewById(R.id.addEntry);
        modifyEntry = findViewById(R.id.modifyEntry);

        delete_entry_1 = findViewById(R.id.delete_entry_1);
        delete_entry_2 = findViewById(R.id.delete_entry_2);
        delete_entry_3 = findViewById(R.id.delete_entry_3);
        delete_entry_4 = findViewById(R.id.delete_entry_4);
        delete_entry_5 = findViewById(R.id.delete_entry_5);
        delete_entry_6 = findViewById(R.id.delete_entry_6);
        delete_entry_7 = findViewById(R.id.delete_entry_7);


        targetWeight = findViewById(R.id.targetWeight);

        day1 = findViewById(R.id.monday);
        day2 = findViewById(R.id.tuesday);
        day3 = findViewById(R.id.wednesday);
        day4 = findViewById(R.id.thursday);
        day5 = findViewById(R.id.friday);
        day6 = findViewById(R.id.saturday);
        day7 = findViewById(R.id.sunday);

        textPermissions = findViewById(R.id.textNotifications);


        //Sets references
        String target_Weight = getTargetWeight();
        String monday = getWeightByDay("monday");
        String tuesday = getWeightByDay("tuesday");
        String wednesday = getWeightByDay("wednesday");
        String thursday = getWeightByDay("thursday");
        String friday = getWeightByDay("friday");
        String saturday = getWeightByDay("saturday");
        String sunday = getWeightByDay("sunday");

        targetWeight.setText("Target Weight: " + target_Weight);
        day1.setText(monday);
        day2.setText(tuesday);
        day3.setText(wednesday);
        day4.setText(thursday);
        day5.setText(friday);
        day6.setText(saturday);
        day7.setText(sunday);

        //Delete entries
        delete_entry_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                appDatabase.weightGridDataDAO().deleteWeightByDay("monday");

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);
            }
        });

        delete_entry_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                appDatabase.weightGridDataDAO().deleteWeightByDay("tuesday");

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

        delete_entry_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                appDatabase.weightGridDataDAO().deleteWeightByDay("wednesday");

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

        delete_entry_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                appDatabase.weightGridDataDAO().deleteWeightByDay("thursday");

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

        delete_entry_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                appDatabase.weightGridDataDAO().deleteWeightByDay("friday");

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

        delete_entry_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                appDatabase.weightGridDataDAO().deleteWeightByDay("saturday");

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

        delete_entry_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                appDatabase.weightGridDataDAO().deleteWeightByDay("sunday");

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });




        //Entry methods that brings to add/modify page
        addEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), Add_Modify_Weight_Entry.class);
                startActivity(intent);

            }
        });

        modifyEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), Add_Modify_Weight_Entry.class);
                startActivity(intent);

            }
        });

        //Entry method that brings to target weight page
        changeTargetWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), Target_Weight.class);
                startActivity(intent);

            }
        });

        //Entry method that verifies SMS permissions on separate page
        textPermissions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), textPermissions.class);
                startActivity(intent);

            }
        });



        //Get phone number for SMS texts
        String phoneNumber = getPhoneNumber(username, password);

        //Sends texts if weight is not null
        if (monday != null) {
            sendTextUpdates(phoneNumber, target_Weight, monday);
        }
        if (tuesday != null) {
            sendTextUpdates(phoneNumber, target_Weight, tuesday);
        }
        if (wednesday != null) {
            sendTextUpdates(phoneNumber, target_Weight, wednesday);
        }
        if (thursday != null) {
            sendTextUpdates(phoneNumber, target_Weight, thursday);
        }
        if (friday != null) {
            sendTextUpdates(phoneNumber, target_Weight, friday);
        }
        if (saturday != null) {
            sendTextUpdates(phoneNumber, target_Weight, saturday);
        }
        if (sunday != null) {
            sendTextUpdates(phoneNumber, target_Weight, sunday);
        }

    }





    //Gets weight by day from weightGrid table
    private String getWeightByDay (String day) {


        String value = appDatabase.weightGridDataDAO().getWeightByDay(day);

        return value;
    }

    //Gets target weight from targetWeight table
    private String getTargetWeight() {

        String value = appDatabase.targetWeightDAO().getTargetWeight(1);

        return value;
    }

    //Gets phone number from loginData table
    private String getPhoneNumber(String username, String password) {

        String number = appDatabase.loginPageDataDAO().getPhoneNumber(username, password);

        return number;
    }

    //Allows for the sending of texts with phone number, target weight, and input weight parameters
    //Sends a different message based on how close the user is to their weight
    private void sendTextUpdates (String phoneNumber, String targetWeight, String inputWeight) {

        String message1 = "You're 10 lbs from your goal!";
        String message2 = "You're 5 lbs from your goal!";
        String message3 = "You have achieved your goal, Congratulations!!!";

        int target = Integer.parseInt(targetWeight);
        int input = Integer.parseInt(inputWeight);

        int x = Math.abs(target - input);

        if (5 < x && x <= 10) {

            textPermissionsForMainPage.sendSMS(phoneNumber, message1);
            Toast.makeText(Main_Page.this, "text sent!", Toast.LENGTH_SHORT).show();

        }
        else if (0 < x && x <= 5) {

            textPermissionsForMainPage.sendSMS(phoneNumber, message2);
            Toast.makeText(Main_Page.this, "text sent!", Toast.LENGTH_SHORT).show();
        }
        else if (x == 0) {

            textPermissionsForMainPage.sendSMS(phoneNumber, message3);
            Toast.makeText(Main_Page.this, "text sent!", Toast.LENGTH_SHORT).show();
        }

    }
}