package com.cs360.cs_360_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import java.util.ArrayList;

//Allows user to add/modify weights
public class Add_Modify_Weight_Entry extends AppCompatActivity {

    //References
    EditText day;
    EditText weight;
    Button addEntry;

    Button returnButton;


    private appDatabase appDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database_grid_add_entry_screen);

        //Sets up connection to database
        appDatabase = Room.databaseBuilder(getApplicationContext(),
                        appDatabase.class, "app_database.db")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        //Finds references
        day = findViewById(R.id.day);
        weight = findViewById(R.id.weight);
        returnButton = findViewById(R.id.returnButton1);
        addEntry = findViewById(R.id.addEntry1);

        //Allows user to add/modify weight in grid on main page
        addEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String thisDay = day.getText().toString().toLowerCase();
                String thisWeight = weight.getText().toString().toLowerCase();

                weightGridData weightGridData = new weightGridData();

                weightGridData.setWDay(thisDay);
                weightGridData.setWWeight(thisWeight);

                appDatabase.weightGridDataDAO().addWeight(weightGridData);
                appDatabase.weightGridDataDAO().updateWeightIfDayExists(thisDay, thisWeight);

                Toast.makeText(Add_Modify_Weight_Entry.this, "Entry Successful!", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

        //Allows user to return to main page if they don't want to edit or add weights
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);

            }
        });

    }
}