package com.cs360.cs_360_project;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;






//Creates table, getters, setters, and constructor for weight grid data
@Entity
public class weightGridData {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long wId;

    //@NonNull
    @ColumnInfo(name = "day")
    private String wDay;

    @ColumnInfo(name = "weight")
    private String wWeight;

    //public weightGridData (@NonNull String day, String weight) {

     //   wDay = day;
     //   wWeight = weight;
   // }

   // public weightGridData (@NonNull String day) {

     //   wDay = day;

  // }

    public weightGridData () {
    }


    public void setWId(long wId) {
        this.wId = wId;
    }

    public void setWDay(String wDay) {
        this.wDay = wDay;
    }

    public void setWWeight(String wWeight) {
        this.wWeight = wWeight;
    }

    public long getWId() {
        return wId;
    }

    public String getWDay() {
        return wDay;
    }

    public String getWWeight() {
        return wWeight;
    }

}
