package com.cs360.cs_360_project;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;


//Database for app
@Database(entities = {weightGridData.class, targetWeightData.class, loginPageData.class}, version = 4)
public abstract class appDatabase extends RoomDatabase {

    //DAO accessors
    public abstract targetWeightData_DAO targetWeightDAO();
    public abstract weightGridData_DAO weightGridDataDAO();
    public abstract loginPageData_DAO loginPageDataDAO();
}

