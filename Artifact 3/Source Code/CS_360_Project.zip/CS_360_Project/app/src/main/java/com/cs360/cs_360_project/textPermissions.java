package com.cs360.cs_360_project;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;

import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

//Allows user to set permissions for SMS privileges

public class textPermissions extends AppCompatActivity {

    public textPermissions() {
    }

    @Override
    protected void onCreate(Bundle SavedInstanceState) {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.sms_permissions_screen);

        verifySMSPermissions();

    }

    // Sends SMS function

    public void sendSMS(String phoneNumber, String message)
    {

            // Get the SMS manager
            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

    }


// Checks for SMS permissions from user
    public void verifySMSPermissions() {

        //Permissions granted

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {

            Intent intent = new Intent(getApplicationContext(), Main_Page.class);
            startActivity(intent);

        }

        //Permissions denied, provide opportunity for user to grant permissions

        else {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);

        }

    }

    // Provides results of user choice for SMS messaging notifications

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                // Permission granted for SMS messaging

                Toast.makeText(textPermissions.this, "Permission Granted, confirmed SMS Messaging", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), Main_Page.class);
                startActivity(intent);


            } else {

                // Permission denied, continue without SMS messaging notification feature

                Toast.makeText(this, "Permission denied, cannot send SMS!" + "Request Code: " + requestCode, Toast.LENGTH_SHORT).show();

            }
        }
    }
}
