/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file allows for the SQL lite operations of the main page.
    It utilizes DAO to perform queries to perform various operations within the program.
    It includes the full CRUD operations for this page.
    It also does have a unique counter to verify unique entries for unique users.
    It has a complete dump delete function used in testing only.
 */

package com.cs499.cs499artifact3v1;

import androidx.room.*;

import java.util.List;

//Allows DAO access to weight grid data table
@Dao
public interface weightGridData_DAO {
    @Query("SELECT weight FROM weightGridData WHERE uniqueID = :uniqueID AND day = :day")
    String getWeightByDay(long uniqueID, String day);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addWeight(weightGridData weightGridData);

    @Query("UPDATE weightGridData SET weight = :newWeight WHERE uniqueID = :uniqueID AND day = :day")
    void updateWeightIfDayExists(long uniqueID, String day, String newWeight);

    @Query("DELETE FROM weightGridData WHERE day = :day")
    void deleteWeightByDay(String day);

    //Unique counter query
    @Query("SELECT COUNT(day) FROM weightGridData WHERE day = :day AND uniqueID = :uniqueID;")
    int countDayWeightGridData(long uniqueID, String day);

    //FOR TESTING PURPOSES ONLY!!!
    @Query("DELETE FROM weightGridData")
    void clearTable();
}
