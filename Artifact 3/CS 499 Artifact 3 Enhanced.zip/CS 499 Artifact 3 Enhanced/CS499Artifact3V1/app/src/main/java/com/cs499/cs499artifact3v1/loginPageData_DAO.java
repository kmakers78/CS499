/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file allows for the SQL lite operations of the login page.
    It utilizes DAO to perform queries to perform various operations within the program.
    It includes the full CRUD operations, but the only operations utilized actively in the program
        are the insert and several read operations for the file.
 */

package com.cs499.cs499artifact3v1;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

//Allows DAO access to login page data table
@Dao
public interface loginPageData_DAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addUsernamePassword(loginPageData loginPageData);

    @Query("SELECT id FROM loginPageData WHERE username = :username AND password = :password")
    int getID(String username, String password);

    @Query("SELECT username FROM loginPageData WHERE username = :username AND password = :password")
    String getUsername(String username, String password);

    @Query("SELECT password FROM loginPageData WHERE username = :username AND password = :password")
    String getPassword(String username, String password);


    /*BELOW METHODS ARE NOT CURRENTLY USED BUT WERE USED FOR TESTING!!
        KEEPING THESE METHODS FOR FUTURE TESTING

    @Query("SELECT phoneNumber FROM loginPageData WHERE username = :username AND password = :password")
    String getPhoneNumber(String username, String password);
    @Query("SELECT * FROM loginPageData WHERE username = :username AND password = :password AND phoneNumber = :phoneNumber")
    loginPageData loginPageData(String username, String password, String phoneNumber);
    @Update
    void updateLogin(loginPageData loginPageData);

    @Delete
    void deleteLogin(loginPageData loginPageData);
     */
}
