/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file contains all the values for the loginPage table of the database.
    It has all the columns and identifiers.
    It contains all the getter/setter methods for these values.
 */

package com.cs499.cs499artifact3v1;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

//Creates table, getters, setters, and constructor for login page data
@Entity
public class loginPageData {

    //Table creation information
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long lId;

    @ColumnInfo(name = "username")
    private String lUsername;

    @ColumnInfo(name = "password")
    private String lPassword;

    @ColumnInfo(name = "phoneNumber")
    private String phoneNumber;

    //General constructor
    public loginPageData() {
    }

    //Getter/setter methods
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public long getLId() {
        return lId;
    }

    public void setLId(long lId) {
        this.lId = lId;
    }

    public String getLUsername() {
        return lUsername;
    }

    public void setLUsername(String lUsername) {
        this.lUsername = lUsername;
    }

    public String getLPassword() {
        return lPassword;
    }

    public void setLPassword(String lPassword) {
        this.lPassword = lPassword;
    }
}
