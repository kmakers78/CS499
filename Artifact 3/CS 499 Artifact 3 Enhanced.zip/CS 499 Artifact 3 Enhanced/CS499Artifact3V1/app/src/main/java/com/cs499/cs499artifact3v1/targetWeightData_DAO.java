/* James Nikolaou
10/18/2024
Contact @ kmakers78@gmail.com
Version 1.2, final revision of the original artifact

This Java file allows for the SQL lite operations of the target weight page.
    It utilizes DAO to perform queries to perform various operations within the program.
    It includes the full CRUD operations, but the delete function is only utilized for testing.
    It also contains a unique counter query to ensure there is unique entries for unique users.
 */

package com.cs499.cs499artifact3v1;

import androidx.room.*;

//Allows DAO access to target weight data table
@Dao
public interface targetWeightData_DAO {
    @Query("SELECT weight FROM targetWeightData WHERE id = :id LIMIT 1")
    String getTargetWeight(long id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addTargetWeight(targetWeightData targetWeightData);

    @Query("UPDATE targetWeightData SET weight = :newWeight WHERE id = :id")
    void updateTargetWeightByID(String newWeight, long id);

    //Unique counter query
    @Query("SELECT COUNT(*) FROM targetWeightData;")
    int countTargetWeightData();

    //ONLY USED FOR TESTING PURPOSES
    @Delete
    void deleteTargetWeight(targetWeightData targetWeight);
}